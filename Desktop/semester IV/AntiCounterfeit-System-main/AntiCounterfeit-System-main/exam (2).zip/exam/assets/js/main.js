document.addEventListener('DOMContentLoaded', function() {
    // Initialize QR Scanner
    const html5QrcodeScanner = new Html5QrcodeScanner(
        "qr-reader",
        { fps: 10, qrbox: 250 }
    );

    function onScanSuccess(decodedText, decodedResult) {
        // Stop scanner
        html5QrcodeScanner.clear();
        
        // Set the scanned value to the input field
        document.getElementById('productCode').value = decodedText;
        
        // Show success message
        showAlert('QR Code scanned successfully!', 'success');
        
        // Automatically submit the form
        document.getElementById('verifyForm').submit();
    }

    function onScanFailure(error) {
        // Handle scan failure
        console.warn(`QR Code scanning failed: ${error}`);
    }

    // Start QR Scanner
    html5QrcodeScanner.render(onScanSuccess, onScanFailure);

    // Form submission handling
    const verifyForm = document.getElementById('verifyForm');
    if (verifyForm) {
        verifyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const productCode = document.getElementById('productCode').value;
            if (!productCode) {
                showAlert('Please enter a product code or scan QR code', 'danger');
                return;
            }

            // Send verification request
            verifyProduct(productCode);
        });
    }

    // Product verification function
    async function verifyProduct(code) {
        try {
            const response = await fetch('verify.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productCode: code })
            });

            const data = await response.json();
            
            if (data.success) {
                showAlert('Product verified successfully!', 'success');
                // Handle successful verification (e.g., show product details)
                if (data.productDetails) {
                    displayProductDetails(data.productDetails);
                }
            } else {
                showAlert(data.message || 'Product verification failed', 'danger');
            }
        } catch (error) {
            console.error('Verification error:', error);
            showAlert('An error occurred during verification', 'danger');
        }
    }

    // Display product details
    function displayProductDetails(details) {
        // Create and show modal with product details
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.id = 'productDetailsModal';
        modal.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Product Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="product-details">
                            <p><strong>Product Name:</strong> ${details.name}</p>
                            <p><strong>Manufacturer:</strong> ${details.manufacturer}</p>
                            <p><strong>Batch Number:</strong> ${details.batchNumber}</p>
                            <p><strong>Manufacturing Date:</strong> ${details.manufacturingDate}</p>
                            <p><strong>Status:</strong> <span class="badge bg-success">Authentic</span></p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const modalInstance = new bootstrap.Modal(modal);
        modalInstance.show();
        
        // Remove modal from DOM after it's hidden
        modal.addEventListener('hidden.bs.modal', function () {
            document.body.removeChild(modal);
        });
    }

    // Alert function
    function showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.role = 'alert';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.container');
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}); 